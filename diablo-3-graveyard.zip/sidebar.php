            <div class="sidebar">
            	<div class="sidebar_top">
                	<div class="sidebar_bot">
						<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
                        <?php endif; ?>
                    </div>                
                </div>
            </div>
