Diablo 3 Graveyard
==================

NOTE: Many of the images in this theme were either part of the Diablo 3 fankit or exist as images on the current Diablo 3 community site at http://www.blizzard.com/diablo3. Many thanks to the designers who work hard to produce such quality work.

See more frequent updates at: https://github.com/zvineyard/diablo-3-graveyard-wordpress-theme