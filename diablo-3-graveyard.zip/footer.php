            <div class="clear"><!-- I hate Internet Explorer--></div>
        
        </div>
        
        <div class="cap"><img src="<?php echo bloginfo('template_directory');?>/images/content-bot.jpg" height="" width="" alt="decorative footer border"/></div>
        <div class="footer">Copyright &copy; <?php echo date('Y'); ?>, <?php echo bloginfo('name');?>. Powered by Wordpress. Theme design by <a href="http://www.zacvineyard.com/d3">Zac Vineyard</a>.</div>
    
    </div>
	
</div>
<?php wp_footer(); ?>
</body>
</html>
