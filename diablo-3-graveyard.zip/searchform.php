<form  method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
    <label class="hidden" for="s"><?php _e('Search:'); ?></label>
    <input type="text" name="s" id="s" class="search right query" />
    <input type="submit" class="search-button" value="" />
</form>